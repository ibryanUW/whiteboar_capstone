gdjs.intro_95sceneCode = {};

gdjs.intro_95sceneCode.conditionTrue_0 = {val:false};
gdjs.intro_95sceneCode.condition0IsTrue_0 = {val:false};


gdjs.intro_95sceneCode.eventsList0 = function(runtimeScene) {

};

gdjs.intro_95sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.intro_95sceneCode.eventsList0(runtimeScene);
return;

}

gdjs['intro_95sceneCode'] = gdjs.intro_95sceneCode;
