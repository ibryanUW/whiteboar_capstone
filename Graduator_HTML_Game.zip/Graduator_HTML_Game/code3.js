gdjs.game_95over_95menuCode = {};
gdjs.game_95over_95menuCode.GDgame_95over_95menuObjects1= [];
gdjs.game_95over_95menuCode.GDgame_95over_95menuObjects2= [];
gdjs.game_95over_95menuCode.GDexitButtonObjects1= [];
gdjs.game_95over_95menuCode.GDexitButtonObjects2= [];
gdjs.game_95over_95menuCode.GDnewGameObjects1= [];
gdjs.game_95over_95menuCode.GDnewGameObjects2= [];
gdjs.game_95over_95menuCode.GDexitObjects1= [];
gdjs.game_95over_95menuCode.GDexitObjects2= [];
gdjs.game_95over_95menuCode.GDcontinueObjects1= [];
gdjs.game_95over_95menuCode.GDcontinueObjects2= [];

gdjs.game_95over_95menuCode.conditionTrue_0 = {val:false};
gdjs.game_95over_95menuCode.condition0IsTrue_0 = {val:false};
gdjs.game_95over_95menuCode.condition1IsTrue_0 = {val:false};


gdjs.game_95over_95menuCode.mapOfGDgdjs_46game_9595over_9595menuCode_46GDnewGameObjects1Objects = Hashtable.newFrom({"newGame": gdjs.game_95over_95menuCode.GDnewGameObjects1});gdjs.game_95over_95menuCode.eventsList0 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("game_over_menu"), gdjs.game_95over_95menuCode.GDgame_95over_95menuObjects1);
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.game_95over_95menuCode.GDgame_95over_95menuObjects1.length !== 0 ? gdjs.game_95over_95menuCode.GDgame_95over_95menuObjects1[0] : null), false, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 5, "", 0);
}{gdjs.evtTools.camera.setCameraX(runtimeScene, 620, "", 0);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("newGame"), gdjs.game_95over_95menuCode.GDnewGameObjects1);

gdjs.game_95over_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.game_95over_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.game_95over_95menuCode.mapOfGDgdjs_46game_9595over_9595menuCode_46GDnewGameObjects1Objects, runtimeScene, true, false);
}if (gdjs.game_95over_95menuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.game_95over_95menuCode.GDnewGameObjects1 */
{for(var i = 0, len = gdjs.game_95over_95menuCode.GDnewGameObjects1.length ;i < len;++i) {
    gdjs.game_95over_95menuCode.GDnewGameObjects1[i].setAnimation(0);
}
}}

}


{


gdjs.game_95over_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.game_95over_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
}if (gdjs.game_95over_95menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "career_fair_intro");
}}

}


{


gdjs.game_95over_95menuCode.condition0IsTrue_0.val = false;
{
gdjs.game_95over_95menuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
}if (gdjs.game_95over_95menuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


};

gdjs.game_95over_95menuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.game_95over_95menuCode.GDgame_95over_95menuObjects1.length = 0;
gdjs.game_95over_95menuCode.GDgame_95over_95menuObjects2.length = 0;
gdjs.game_95over_95menuCode.GDexitButtonObjects1.length = 0;
gdjs.game_95over_95menuCode.GDexitButtonObjects2.length = 0;
gdjs.game_95over_95menuCode.GDnewGameObjects1.length = 0;
gdjs.game_95over_95menuCode.GDnewGameObjects2.length = 0;
gdjs.game_95over_95menuCode.GDexitObjects1.length = 0;
gdjs.game_95over_95menuCode.GDexitObjects2.length = 0;
gdjs.game_95over_95menuCode.GDcontinueObjects1.length = 0;
gdjs.game_95over_95menuCode.GDcontinueObjects2.length = 0;

gdjs.game_95over_95menuCode.eventsList0(runtimeScene);
return;

}

gdjs['game_95over_95menuCode'] = gdjs.game_95over_95menuCode;
