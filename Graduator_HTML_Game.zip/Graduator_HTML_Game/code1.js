gdjs.help_95text_95introCode = {};
gdjs.help_95text_95introCode.GDIntroHelpDeskObjects1= [];
gdjs.help_95text_95introCode.GDIntroHelpDeskObjects2= [];
gdjs.help_95text_95introCode.GDinfo_95text_95bgObjects1= [];
gdjs.help_95text_95introCode.GDinfo_95text_95bgObjects2= [];
gdjs.help_95text_95introCode.GDaction_95needed_95textObjects1= [];
gdjs.help_95text_95introCode.GDaction_95needed_95textObjects2= [];

gdjs.help_95text_95introCode.conditionTrue_0 = {val:false};
gdjs.help_95text_95introCode.condition0IsTrue_0 = {val:false};
gdjs.help_95text_95introCode.condition1IsTrue_0 = {val:false};
gdjs.help_95text_95introCode.condition2IsTrue_0 = {val:false};
gdjs.help_95text_95introCode.conditionTrue_1 = {val:false};
gdjs.help_95text_95introCode.condition0IsTrue_1 = {val:false};
gdjs.help_95text_95introCode.condition1IsTrue_1 = {val:false};
gdjs.help_95text_95introCode.condition2IsTrue_1 = {val:false};


gdjs.help_95text_95introCode.eventsList0 = function(runtimeScene) {

{


{
{gdjs.evtTools.camera.setCameraX(runtimeScene, 420, "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, 200, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 4, "", 0);
}{gdjs.evtTools.window.centerWindow(runtimeScene);
}{}}

}


{


gdjs.help_95text_95introCode.condition0IsTrue_0.val = false;
gdjs.help_95text_95introCode.condition1IsTrue_0.val = false;
{
gdjs.help_95text_95introCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if ( gdjs.help_95text_95introCode.condition0IsTrue_0.val ) {
{
{gdjs.help_95text_95introCode.conditionTrue_1 = gdjs.help_95text_95introCode.condition1IsTrue_0;
gdjs.help_95text_95introCode.condition0IsTrue_1.val = false;
{
gdjs.help_95text_95introCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Return");
if( gdjs.help_95text_95introCode.condition0IsTrue_1.val ) {
    gdjs.help_95text_95introCode.conditionTrue_1.val = true;
}
}
{
}
}
}}
if (gdjs.help_95text_95introCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "career_fair_intro", false);
}}

}


{


{
}

}


};

gdjs.help_95text_95introCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.help_95text_95introCode.GDIntroHelpDeskObjects1.length = 0;
gdjs.help_95text_95introCode.GDIntroHelpDeskObjects2.length = 0;
gdjs.help_95text_95introCode.GDinfo_95text_95bgObjects1.length = 0;
gdjs.help_95text_95introCode.GDinfo_95text_95bgObjects2.length = 0;
gdjs.help_95text_95introCode.GDaction_95needed_95textObjects1.length = 0;
gdjs.help_95text_95introCode.GDaction_95needed_95textObjects2.length = 0;

gdjs.help_95text_95introCode.eventsList0(runtimeScene);
return;

}

gdjs['help_95text_95introCode'] = gdjs.help_95text_95introCode;
