gdjs.animated_95intro_95cutsceneCode = {};
gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1= [];
gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects2= [];

gdjs.animated_95intro_95cutsceneCode.conditionTrue_0 = {val:false};
gdjs.animated_95intro_95cutsceneCode.condition0IsTrue_0 = {val:false};
gdjs.animated_95intro_95cutsceneCode.condition1IsTrue_0 = {val:false};


gdjs.animated_95intro_95cutsceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.animated_95intro_95cutsceneCode.condition0IsTrue_0.val = false;
{
gdjs.animated_95intro_95cutsceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.animated_95intro_95cutsceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("intro_cutscene"), gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1);
{gdjs.evtTools.camera.setCameraX(runtimeScene, 2500, "", 0);
}{gdjs.evtTools.camera.setCameraY(runtimeScene, 2500, "", 0);
}{gdjs.evtTools.window.centerWindow(runtimeScene);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1.length !== 0 ? gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1[0] : null), true, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{for(var i = 0, len = gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1.length ;i < len;++i) {
    gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1[i].play();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("intro_cutscene"), gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1);

gdjs.animated_95intro_95cutsceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1.length;i<l;++i) {
    if ( gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1[i].isEnded() ) {
        gdjs.animated_95intro_95cutsceneCode.condition0IsTrue_0.val = true;
        gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1[k] = gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1[i];
        ++k;
    }
}
gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1.length = k;}if (gdjs.animated_95intro_95cutsceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "help_text_intro", false);
}}

}


};

gdjs.animated_95intro_95cutsceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects1.length = 0;
gdjs.animated_95intro_95cutsceneCode.GDintro_95cutsceneObjects2.length = 0;

gdjs.animated_95intro_95cutsceneCode.eventsList0(runtimeScene);
return;

}

gdjs['animated_95intro_95cutsceneCode'] = gdjs.animated_95intro_95cutsceneCode;
